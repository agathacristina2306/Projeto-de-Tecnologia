// Lista de vídeos com títulos e URLs
let videos = [
  { title: "Vídeo 1", url: "https://scratch.mit.edu/projects/27486420" },
  { title: "Vídeo 2", url: "https://scratch.mit.edu/projects/27486484" },
  { title: "Vídeo 3", url: "https://scratch.mit.edu/projects/27486676" }
];

function setup() {
  createCanvas(400, 400); // Cria o canvas
  background(220); // Fundo cinza claro
  
  textAlign(CENTER, CENTER); 
  textSize(20);
  fill(0);
  text("Catálogo de Vídeos", width / 2, 50); // Título no topo

  // Exibe os vídeos
  displayVideos();
}

function displayVideos() {
  let y = 100; // Posição inicial vertical para os links
  textSize(16);

  for (let video of videos) {
    // Exibe o título do vídeo
    text(video.title, width / 2, y - 10);

    // Cria o link clicável
    let link = createA(video.url, "Assistir", "_blank");
    link.position(width / 2 - 30, y); // Posiciona o link abaixo do título
    link.style("color", "blue"); // Cor azul para o link
    link.style("font-size", "14px");

    y += 50; // Move para a próxima linha
  }
}
