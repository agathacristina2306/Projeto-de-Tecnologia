let stage = 0; // Define o estágio inicial da aventura

function setup() {
  createCanvas(400, 400); // Cria um canvas de 400x400 pixels
  textAlign(CENTER, CENTER);
}

function draw() {
  background(0, 0, 255); // Cor de fundo azul em RGB (R: 0, G: 0, B: 255)
  
  if (stage === 0) {
    // Introdução
    textSize(20);
    fill('white'); // Cor do texto para contraste
    text("Bem-vindo à sua aventura!", width / 2, height / 2 - 50);
    text("Pressione [D] para ir para a direita", width / 2, height / 2);
    text("Pressione [E] para ir para a esquerda", width / 2, height / 2 + 50);
  } else if (stage === 1) {
    // Caminho da direita
    textSize(20);
    fill('white');
    text("Você encontra uma caverna escura.", width / 2, height / 2 - 50);
    text("Pressione [S] para entrar na caverna", width / 2, height / 2);
    text("Pressione [N] para voltar para casa", width / 2, height / 2 + 50);
  } else if (stage === 2) {
    // Caminho da esquerda
    textSize(20);
    fill('white');
    text("Você encontra um rio.", width / 2, height / 2 - 50);
    text("Pressione [T] para atravessar o rio", width / 2, height / 2);
    text("Pressione [B] para pegar um barco", width / 2, height / 2 + 50);
  } else if (stage === 3) {
    // Tesouro
    textSize(16);
    fill('white');
    text("Você encontrou um tesouro escondido! Parabéns!", width / 2, height / 2);
  } else if (stage === 4) {
    // Voltar para casa
    textSize(16);
    fill('white');
    text("Você decidiu voltar para casa em segurança.", width / 2, height / 2);
  } else if (stage === 5) {
    // Levado pela correnteza
    textSize(16);
    fill('white');
    text("Você foi levado pela correnteza. Fim do jogo!", width / 2, height / 2);
  } else if (stage === 6) {
    // Barco seguro
    textSize(15);
    fill('white');
    text("Você encontrou um barco e navegou para um lugar seguro.", width / 2, height / 2);
  }
}

function keyPressed() {
  if (stage === 0) {
    if (key === 'D' || key === 'd') {
      stage = 1; // Vai para a direita
    } else if (key === 'E' || key === 'e') {
      stage = 2; // Vai para a esquerda
    }
  } else if (stage === 1) {
    if (key === 'S' || key === 's') {
      stage = 3; // Entra na caverna
    } else if (key === 'N' || key === 'n') {
      stage = 4; // Volta para casa
    }
  } else if (stage === 2) {
    if (key === 'T' || key === 't') {
      stage = 5; // Atravessa o rio
    } else if (key === 'B' || key === 'b') {
      stage = 6; // Pega o barco
    }
  }
}
